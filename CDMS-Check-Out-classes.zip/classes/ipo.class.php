<?php
	require_once 'db_row.class.php';
	require_once 'placement.class.php';
 
	class ipo{

		public $cp_no = '';
		public $indexNo=0;
		public $firstName='';
		public $lastName='';
		public $eom ='';
		public $doa ='';
		public $email = '';
		public $nextofkin_name ='';
		public $nextofkin_contact_no='';
		public $nextofkin_contact_address;
		public $post_id =0;
		public $position = NULL;
		public $unit_id = 0;
		public $unit_name = '';
		public $teamSite_id = 0;
		public $teamSite_name='';
		public $sector_id = 0;
		public $unitSupervisor_post_id=0;
		public $sectorSupervisor_post_id=0;
		public $contingent_id=0;
		protected $conn =null;

		function __construct($_cp_no = ''){

			$this->conn = new db_rows();
				
			
			if($_cp_no !=='') 
					$this->getIPO($_cp_no);
			
		}
		
		function getIPO($_cp_no){
			
			$table = "ipo";
			$fields = 	array('cp_no', 
							'IndexNo', 
							'LastName', 
							'FirstName', 
							'cntr_id', 
							'post_id', 
							'doa', 
							'eom', 
							'email_address',
							'em_contact_name',
							'em_contact_address',
							'em_contact_phone'
							
						);
						
			 $key = "cp_no= '$_cp_no'";
			$row=$this->conn->get_rows($table, $fields, $key );
			
			if(is_array($row)){
				
				$this->cp_no = $row[0]['cp_no'];
				$this->indexNo=$row[0]['IndexNo'];
				$this->firstName=$row[0]['FirstName'];
				$this->lastName= $row[0]['LastName'];
				$this->post_id =$row[0]['post_id'];
				$this->eom =$row[0]['eom'];
				$this->doa =$row[0]['doa'];
				$this->email =$row[0]['email_address'];
				$this->nextofkin_name = $row[0]['em_contact_name'];
				$this->nextofkin_contact_no= $row[0]['em_contact_phone'];
				$this->nextofkin_contact_address = $row[0]['em_contact_address'];
				$this->position = new position($this->post_id);
				
			}
			else
				echo 'Empty ';
		}			

		
		function getIPOs($_filter=0){
		}
		
	}

	