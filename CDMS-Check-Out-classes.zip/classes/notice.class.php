<?php
require_once('db_row.class.php');

class  notice{
    
	
	public function __construct(){
	    protected $notice[]= array();
		$notice['notice_id'] = 0;
		$notice['notice_sender_post_id'] = 0;
		$notice['notice_title'] = '';
		$notice['notice_action_page]' = '';
		$notice['notice_sent_time']=0;
		$notice['notice_sender_cp_no']='';	
		$notice['notice_sender_names'] = ''; //First Name and Last Name of sender
		$notice['notice_sender_location'] = '';  // Unit and Department of sender
		public $db = new db_rows();
	}
	
	public function readPositioNotice($post_id, $notice_id=0){
	   $feilds = array('ipo.cp_no', 
						"CONCAT(ipo.FirstName,' ', ipo.LastName) as sender_name", 
						'units.unit_name',
						'units.unit',
						'
						);
		$note = $this->$db->get_rows("ipo INNER JOIN position "
	}
	
	public function readPrivateNotice($cp_no, $notice_id=0){
	
		
	}
	
	public function addNotice($pstNotice[], $notice_type){
	}
	
	
	
	
	
}

?>