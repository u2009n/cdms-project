<?php

	//object of the the IPO Contingent; 
	
	require_once '/classes/db_row.class.php';
	require_once '/classes/ipo.class.php';
	
	class contingent{
		public $contingent = 0;
		public $cont_name ='';
		public $cont_code ='';
		public $cont_category=0;
		protected $cont_commandr_cpno=0;
		public $contingent_commander = NULL;
		public $destinations = array();
		
		
		function __construct($_contingent_id=0){
			$this->contingent_commander = new ipo();
			if($_contingent_id > 0) $this->getContingent($_contingent_id); 
		}
		
		function getContingent($_contingent_id){
			$conn= new db_rows();
			
			$fields= array( array('country.cntr_name', 'cont_name'),
							array('country.cntr_code', 'cont_code'),
							array('country.cntr_type', 'cont_category')
					 );
					
			$table = "country";			
			$key = "cntr_id = $_contingent_id";
			$row=$conn->get_rows($table, $fields);
			
			if(is_array($row) && !empty($row)){
				$this->cont_name = $row[0]['cont_name'];
				$this->cont_code = $row[0]['cont_code'];
				$this->cont_commandr_cpno=$row[0]['cont_commandr_cpno'];
				
				
			}
			
		} 
		
		function getContingentCommander($_contingent_id){
				$table= "cont_commandr";
				$fields = array('ccp_no');
				$row=$conn->get_rows($table, $fields);
				if(is_array($row) && !empty($row)){
					$this->cont_commandr_cpno = $row[0]['ccp_no'];
				  
					if(trim($this->cont_commandr_cpno) !=='')
							$this->contingent_commander = new	ipo($this->cont_commandr_cpno);
						
					  
				}
		}
		
		function get_members($_contingent_id){
			$table = "cont_commandr";
			$this->contingent_commander = new ipo($cont_commandr_cpno);
		}
		
		function getDestinations($_contingent_id){
			$table = "towns";
			$fields = array("town_name", "town_id");
			$key = "cntr_id = $_contingent_id";
			$row=$conn->get_rows($table, $fields);
			
			$row=$conn->get_rows($table, $fields, $key);
			
			if(is_array($row) && !empty($row))
				$destinations = $row;									  
			
		}
	}
?>