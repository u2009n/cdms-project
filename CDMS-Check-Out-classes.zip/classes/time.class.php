<?php
	
	
	class _time{
		
		function time_box($h_name, $m_name, $default_h=NULL, $default_m = NULL){
			echo "<select name=\"$h_name\" size=\"1\">\n\t\t\t\t<option>--hh--</option>\n\t\t\t\t"; 
			
			for($h = 0; $h<24; $h++){
				$hr = (strlen("$h") == 1) ? "0$h" : $h;
				echo "<option value=\"$hr\" ".$sel=(($hr==$default_h)? "selected=\"selected\"" : NULL).">$hr</option>\n\t\t\t\t";
			}
			echo "</select><select name=\"$m_name\">\n\t\t\t\t<option>--mm--</option>\n\t\t\t\t"; 
			
			for($m =0; $m<60; $m++){
				$min = (strlen("$m") == 1) ? "0$m" : $m; 
				echo "<option value=\"$min\" ".$sel=(($min==$default_m)? "selected=\"selected\"" : NULL)."> $min </option>\n\t\t\t\t";
			}	
			echo "</select>";
		}
		
		function date_box($d_name, $m_name, $y_name, $default_d=NULL, $default_m=NULL, $default_y=NULL){
			echo "<select name=\"$d_name\"><option>--dd--</option>"; 
						
			for($d = 0; $d < 32; $d++){ 
				$day = (strlen("$d") == 1) ? "0$d" : $d;
				
				echo "<option value=\"$day\" ".$sel=(($day==$default_d)? "selected=\"selected\"" : NULL).">$day</option>\n\t\t\t\t";
			}
			echo "</select>";
			
			echo "<select name=\"$m_name\"> \n\t\t\t\t<option>--Month--</option> \n\t\t\t\t"; 
						
			for($m = 1; $m < 13; $m++){ 
				$m = (strlen("$m") == 1) ? "0$m" : $m;
				echo "<option value=\"$m\" ".$sel=(($m==$default_m)? "selected=\"selected\"" : NULL)."> ". date('F', strtotime("1900-$m-23")) ."</option>\n\t\t\t\t";
			}
			echo "</select>";
			
			echo "<select name=\"$y_name\"><option>--yyyy--</option>"; 
			$cy = date("Y");
					
			for($y = $cy; $y >  1900; $y--)				
				echo "<option value=\"$y\" ".$sel=(($y==$default_y)? "selected=\"selected\"" : NULL)."> $y</option>\n\t\t\t\t";
			
			echo "</select>";
				
		}
		
		
	}
	
?>
