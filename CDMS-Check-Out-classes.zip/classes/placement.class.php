<?php

	require_once 'db_row.class.php';
	
	
			
	class sector{
		public $sector_id = 0;
		public $sector_name ='';
		public $errors=array();
		protected $conn=null;
		
		function __construct($_sector_id=0){

			$this->conn = new db_rows();
			
			if($_sector_id > 0) $this->getSector($_sector_id);
			
		}
	
		function getSector($_sector_id){
			$table = "sectors";
			$fields = array("sec_id", 'sec_name'); 
			$key = "sec_id=$_sector_id";

			if(is_array($row=$this->conn->get_rows($table, $fields, $key))){
				$this->sector_id = $_sector_id;
				$this->sector_name=$row[0]['sec_name'];
				
				echo "<p>".$this->sector_name."</p>";
				
			}
			
		}
		
		public function getSector_teamsites($_sector_id){
			$table = 'units';
			$fields = array('ts_id', 'ts_name');
			$key= "sec_id=$_sector_id";
			
			if(is_array($rows=$this->conn->get_rows($table, $fields, $key))){
				return $rows;
				
			}	
			else
				return NULL;
			
			
		}
	}
	
	/*********************************************************************************************/
    
	class teamsite extends sector{
		public $teamsite_id=0;
		public $teamsite_name = '';	
		
		function __construct($_teamsite_id=0){
			$this->conn = new db_rows();
			if($_teamsite_id > 0) $this->getTeamsite($_teamsite_id);
			
		}
		
		public function geTeamsite($_teamsite_id){
			$table = "teamsites";
			$fields = array('ts_id', 'ts_name', 'sec_id');
			$key= "ts_id = $_teamsite_id ";
			
			if(is_array($row=$this->conn->get_rows($table, $fields, $key))){
				$this->teamsite_id = $row[0]['ts_id'];
				$this->teamsite_name=$row[0]['ts_name'];
				$this->sector_id = $row[0]['sec_id'];
				$this->getSector($this->sector_id);
				
			}	
			
		}
		
		public function getTeamsitUnits(){
		}
		
	}
	
	
	class unit extends teamsite{
		public $teamsite_id=0;
		public $unit_id = 0;
		public $unit_name = '';
		public $unit_supvsr_post_id =0;
		public $section_supvsr_post_id=0;
		
		function __construct($_unit_id=0){
			$this->conn = new db_rows();
			if($_unit_id > 0) $this->getUnit($_unit_id);
			
		}	
		
		public function getUnit($_unit_id){ //search db for specific position
			$table = 'units';
			$key = "unit_id = $_unit_id";
			$fields = array('unit_name', 
							array('unit_supervisor', 'supvsr_post_id'), 
							array('ts_id', 'teamsite_id'),							
						   array('section_supervisor', 'section_supvsr_post_id'),
						);
			
			if(is_array($row=$this->conn->get_rows($table, $fields, $key))){
				$this->unit_id= $_unit_id;
				$this->unit_name= $row[0]['unit_name'];
				$this->unit_supvsr_post_id= $row[0]['supvsr_post_id'];
				$this->section_supvsr_post_id=$row[0]['section_supvsr_post_id'];
				$this->geTeamsite($row[0]['teamsite_id']);
			}
		}
		
		public function getUnit_Positions($_unit_id){ //returns array of positions in unit 
			
			$table = 'positions';
			$fields = array('post_id', 'post_name', 'keypost', 'supervisor');
			$key = "unit_id = $_unit_id";
			
			if(is_array($row=$this->conn->get_rows($table, $fields, $key)))
				return $row;
			
		}
	}
	
	class position{
		public $post_id=0;
		public $post_name = '';
		protected $unit_id = 0;
		public $unit = null;
		public $post_plan = 0;
		protected $unit_supvsr_post_id=0;
		public $post_category_id = 0;
		public $post_category_name ='';
		protected $conn=NULL;
		
			
		public function __construct($_post_id=0){			
			$this->conn = new db_rows();
			$this->unit = new unit();
			if($_post_id > 0) $this->getPosition($_post_id);
		}
		
		public function getPosition($_post_id){
		   $table = 'positions INNER JOIN categories on positions.category = categories.id AND  positions.post_id = '. $_post_id;
		   $fields = array(array('positions.post_name', 'post'), 
						   array('positions.unit_id', 'unit_id'), 
						   array('positions.planned', 'planned'),
						   array('positions.supervisor', 'supvsr'),
						   array('categories.ID', 'category_id'),
						   array('categories.Category', 'category_name') 
					 );
						   
		   
		   
		    if(is_array($row=$this->conn->get_rows($table, $fields))){
				$this->post_id = $_post_id;
				$this->post_name=$row[0]['post'];
				$this->unit_id = $row[0]['unit_id'];
				$this->supvsr_post_id =$row[0]['supvsr'];
				$this->post_category_id= $row[0]['category_id'];
				$this->post_category_name=$row[0]['category_name'];
				$this->unit->getUnit($this->unit_id);
				
			}	
		
				
		}
			
	}
	
?>