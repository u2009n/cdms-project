<?php
	require_once('

	class checkoutList(){
		
		function getList(){
			$fields = array('cp_no', 'firstName', 'lastName', '');
		}
		
	}
?>