<?php
	require_once 'db_row.class.php';
	require_once 'ipo.class.php';
	
	class noticas{

		public $casualty = new ipo();
		protected $conn = new db_rows();
		public $incident_date = '';
		public $incident_location;

		public function __construct($_cp_no=''){
			if($_cp_no !=='')
				
			
		
		}
	}
?>